using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lava : MonoBehaviour
{

    private float heightincrement = 0f;

    public GameObject loseScr;

    public float increment = 0.1f;
    public float max = 10f; 
    
    private void Start(){
        StartCoroutine(increaseDif());
    }

    private void Update(){
        transform.localScale += new Vector3(0f,heightincrement * Time.deltaTime,0f);
        transform.position += new Vector3(0f,heightincrement/2 * Time.deltaTime,0f);
    }

    public IEnumerator increaseDif(){
        while(true){
        yield return new WaitForSeconds(5f);
        if(heightincrement <= max){
            heightincrement += increment;
        } 
        }
    }

    private void OnTriggerEnter2D(Collider2D other){
        if(other.tag == "Player"){
            Destroy(other.GetComponent<playerMovement>());
            other.transform.localRotation = Quaternion.Euler(0, 0,90f);
            Instantiate(loseScr);
            StopCoroutine(increaseDif());
        }
    }

    void OnDestroy()
    {
        StopCoroutine(increaseDif());
    }
}
