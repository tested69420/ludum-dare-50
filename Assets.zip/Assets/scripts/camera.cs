using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class camera : MonoBehaviour
{
    public Transform player;

    void Update()
    {
        Vector3 dir = Vector2.Lerp(transform.position, player.position, 0.1f);
        dir.z = -10;
        transform.position = dir;
    }

}
