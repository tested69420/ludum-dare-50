using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerMovement : MonoBehaviour
{

    public Rigidbody2D rb;

    public AudioSource audioSource;

    public float speed = 10f;
    public float jumpheight = 5f;

    public LayerMask gl;
    public Transform gc;

    private string dir = "right";

    private float input;



    // Update is called once per frame
    void Update()
    {
        input = Input.GetAxis("Horizontal");
        float jump = Input.GetAxisRaw("Vertical");

        rb.velocity = new Vector2(input * speed * 60 * Time.deltaTime,rb.velocity.y);

        if(jump == 1f && Physics2D.OverlapCircle(gc.position,0.02f,gl) != null){
            rb.velocity = Vector2.up * jumpheight;
            audioSource.Play();
        }

        handleFlip();
    }

    void handleFlip(){
        if(input > 0){
            dir = "right";
        }
        if(input < 0){
            dir = "left";
        }

        if(dir == "right"){
            transform.localRotation = Quaternion.Euler(0, 0, input * 5f);
        }
        if(dir == "left"){
            transform.localRotation = Quaternion.Euler(0f,180,-input * 5f);
        }
    }
}
