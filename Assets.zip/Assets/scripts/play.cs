using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class play : MonoBehaviour
{
    public void begin(){
        SceneManager.LoadScene("game");	//Loads the game scene
    }

    public void titlereturn(){
        SceneManager.LoadScene("start");	//Loads the start scene
    }
}
