using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bullet : MonoBehaviour
{
    public Rigidbody2D rb;
    public float velocity;

    void Start(){
        Destroy(gameObject,30f);
    }

    void Update(){
        rb.velocity = new Vector2(velocity,0);
    }
}
