using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cannon : MonoBehaviour
{
    public GameObject shot;
    public float fireRate;

    private void Start(){
        StartCoroutine(shoot());
    }

    public IEnumerator shoot(){
        while(true){
            Debug.Log("shot");
            Instantiate(shot, transform.position, transform.rotation);
            yield return new WaitForSeconds(fireRate);
        }
    }
}
