using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class coin : MonoBehaviour
{
    public AudioSource audio;
    public GameObject winScreen;
    public lava lavaScript;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            audio.Play();
            Instantiate(winScreen);
            Destroy(other.GetComponent<playerMovement>());
            other.GetComponent<Rigidbody2D>().velocity = Vector2.zero;
            Destroy(lavaScript);
        }
    }
}
